// Mobile Menu
const menuBtn = document.querySelector('.menu-btn');
const mobileMenu = document.querySelector('.menus');

menuBtn.addEventListener('click', () => {
  menuBtn.classList.toggle('active');
  mobileMenu.classList.toggle('active');
  menuBtn.querySelector('i').classList.toggle('fa-bars');
  menuBtn.querySelector('i').classList.toggle('fa-times');
});

// Dynamic Text
const dynamicText = document.getElementById('dynamic-text');
const phrases = ['pay bills', 'pay money','Buy online'];
let currentIndex = 0;

function changeText() {
    dynamicText.style.transitionDuration = '1.5s';
    dynamicText.style.opacity = 0;
    setTimeout(() => {
        dynamicText.textContent = phrases[currentIndex];
        currentIndex = (currentIndex + 1) % phrases.length;
        dynamicText.style.opacity = 1;
    }, 1500);
}

setInterval(changeText, 3000);